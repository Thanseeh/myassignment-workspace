package com.assignment.lamdaaws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.assignment.lamdaaws.configuration.EmailService;

@SpringBootApplication
@ComponentScan(basePackages = {"com.assignment.lamdaaws","com.assignment.lamdaaws.configuration","com.assignment.lamdaaws.handler"})
public class LamdabrodcastApplication {

	
	
	public static void main(String[] args) {
		SpringApplication.run(LamdabrodcastApplication.class, args);
	}

}
