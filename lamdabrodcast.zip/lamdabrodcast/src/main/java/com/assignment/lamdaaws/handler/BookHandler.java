package com.assignment.lamdaaws.handler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.assignment.lamdaaws.configuration.EmailService;

@Component
public class BookHandler implements RequestHandler<APIGatewayProxyRequestEvent, APIGatewayProxyResponseEvent> {

	@Autowired
	EmailService mailSender;
	String message = "No message to display";

    @Override
    public APIGatewayProxyResponseEvent handleRequest(APIGatewayProxyRequestEvent input, Context context) {
    	String tempMessage = null,toMsg,subMsg;
    	try{
    		
//    		toMsg = input.getQueryStringParameters().get("to");
//    		subMsg = input.getQueryStringParameters().get("subject");
//    		System.out.println(input);
//    		System.out.println(input.getBody());
    		tempMessage = input.getQueryStringParameters().get("message");
    		System.out.println(tempMessage);
    		if(tempMessage != null) {
    			message =  tempMessage;
    		}
        } catch(Exception e){
            return new APIGatewayProxyResponseEvent().withBody("Mail not send").withStatusCode(200);
        }
    	System.out.println("Sending message");
    	 AnnotationConfigApplicationContext annotationConfigApplicationContext = new AnnotationConfigApplicationContext(EmailService.class);
    	 mailSender = annotationConfigApplicationContext.getBean(EmailService.class);
    	 mailSender.sendSimpleMessage("toemail", "Complaint Message!!!Important", tempMessage);
        return new APIGatewayProxyResponseEvent().withBody("Mail Successfully send , Will get back to you soon...").withStatusCode(200);
    }

    public APIGatewayProxyResponseEvent handleRequest2(APIGatewayProxyRequestEvent input, Context context) {
            return new APIGatewayProxyResponseEvent().withBody(message).withStatusCode(200);
    }
    

}