package com.assignment.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.assignment.entity.BookFlight;
import com.assignment.exceptions.NotFoundException;
import com.assignment.model.BookFlightVo;
import com.assignment.model.FlightVo;
import com.assignment.service.UserService;

@RestController
@RequestMapping("/api/v1.0/flight/user")
public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	RestTemplate restTemplate;

	/*
	 * http://localhost:8L080/api/v1.0/flight/user/search
	 */
	@PostMapping("/search")
	public List<FlightVo> findBy(@RequestBody FlightVo bookFlight) {
		// find all flights from database -> admin-service

		String url = "http://adminservice/api/v1.0/flight/user/search";
		System.out.println(bookFlight);
		HttpMethod method = HttpMethod.POST;
		HttpEntity<?> requestEntity = new HttpEntity<>(bookFlight);
		ParameterizedTypeReference<List<FlightVo>> responseType = new ParameterizedTypeReference<List<FlightVo>>() {
		};

		ResponseEntity<List<FlightVo>> res = restTemplate.exchange(url, method, requestEntity, responseType);
		System.out.println("printing body");
		System.out.println(res.getBody());
		return res.getBody();
	}

	/*
	 * http://localhost:8080/api/v1.0/flight/user/ticket/{pnr}
	 */
	@GetMapping("/ticket/{pnrNo}")
	public List<BookFlight> viewHistoryViaPnr(@PathVariable String pnrNo) {
		return userService.findByPnrNo(pnrNo);
	}

	/*
	 * http://localhost:8080/api/v1.0/flight/user/booking/history/{emailId}
	 */
	@GetMapping("/booking/history/{emailId}")
	public List<BookFlight> viewHistory(@PathVariable String emailId) {
		return userService.findByEmailId(emailId);
	}

	/*
	 * http://localhost:8080/api/v1.0/flight/user/booking/{flightId}
	 */
	@PostMapping("/booking/{flightId}")
	public BookFlightVo addFlightBooking(@RequestBody BookFlightVo bookFlight, @PathVariable("flightId") int flightId) throws NotFoundException {
		String url = "http://adminservice/api/v1.0/flight/user/getDetails/"+flightId;
		System.out.println(bookFlight);
		HttpMethod method = HttpMethod.GET;
		HttpEntity<?> requestEntity = new HttpEntity<>(null, null);
		ParameterizedTypeReference<FlightVo> responseType = new ParameterizedTypeReference<FlightVo>() {
		};

		ResponseEntity<FlightVo> res = restTemplate.exchange(url, method, requestEntity, responseType);
		System.out.println("printing response" + res.getBody());
		FlightVo body = res.getBody();
		if(body.getFlightNumber() != null) {
			bookFlight.setFlightNo(body.getFlightNumber());
			bookFlight.setBookFlightTime(body.getStartDate());
			bookFlight.setBookFlightFrom(body.getFromPlace());
			bookFlight.setBookFlightDestinationTime(body.getEndDate());
			bookFlight.setBookFlightTo(body.getToPlace());
			bookFlight.setAirlineName(bookFlight.getAirlineName());
			return userService.addFlightBooking(bookFlight);
		}
		throw new NotFoundException("Booking unsuccessFul");
	}

	/*
	 * http://localhost:8080/api/v1.0/flight/user/booking/cancel/{pnrNo}
	 */
	@DeleteMapping("/booking/cancel/{pnrNo}")
	public boolean deleteFlightBooking(@PathVariable String pnrNo) {
		return userService.deleteFlightBooking(pnrNo);
	}

}
