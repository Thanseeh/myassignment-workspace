package com.assignment.entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NotFound;
import org.springframework.lang.NonNull;

import com.sun.istack.NotNull;

@Entity
@Table(name = "BK_FLIGHT")
public class BookFlight {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "BK_FLIGHTID")
	private int bookFlightId;
	
	@Column(name = "BK_USERNAME")
	@NonNull
	private String userName;
	
	@Column(name = "BK_FLIGHTNO")
	@NonNull
	private String flightNo;
	
	@Column(name = "BK_FLIGHTAIRLINE")
	@NonNull
	private String flightAirlineName;
	
	@Column(name = "BK_FLIGHTFROM")
	@NonNull
	private String bookFlightFrom;
	
	@Column(name = "BK_FLIGHTTO")
	@NonNull
	private String bookFlightTo;
	
	
	@Column(name = "BK_FLIGHTTIME")
	@NonNull
	private LocalDateTime bookFlightTime;
	
	@Column(name = "BK_FLIGHT_DESTTIME")
	@NonNull
	private LocalDateTime bookFlightDestinationTime;
	
	@Column(name = "BK_BOOKTIME")
	private LocalDateTime bookingTime;
	
	@PrePersist
	private void onCreate() {
		bookingTime = LocalDateTime.now();
	}
	
	@Column(name = "BK_EMAILID")
	@NotNull
	private String emailId;
	
	@Column(name = "BK_PNRNO")
	@NotNull
	private String pnrNo;
	
	@Column(name = "BK_MEAL")
	private String bookMeal;
	
	//passenger entries
	@Column(name = "PS_NAME")
	private String passengerName;
	
	@Column(name = "PS_GENDER")
	private String passengerGender;
	
	@Column(name = "PS_AGE")
	private int age;
	
	@Column(name = "BK_TYPE")
	//value 0 then one way otherwise 2 way
	private int tripType;
	
	@Column(name="BK_STATUS")
	private String bookStatus;
	
	

	public String getFlightAirlineName() {
		return flightAirlineName;
	}

	public void setFlightAirlineName(String flightAirlineName) {
		this.flightAirlineName = flightAirlineName;
	}

	public String getBookFlightFrom() {
		return bookFlightFrom;
	}

	public void setBookFlightFrom(String bookFlightFrom) {
		this.bookFlightFrom = bookFlightFrom;
	}

	public String getBookFlightTo() {
		return bookFlightTo;
	}

	public void setBookFlightTo(String bookFlightTo) {
		this.bookFlightTo = bookFlightTo;
	}

	public LocalDateTime getBookFlightDestinationTime() {
		return bookFlightDestinationTime;
	}

	public void setBookFlightDestinationTime(LocalDateTime bookFlightDestinationTime) {
		this.bookFlightDestinationTime = bookFlightDestinationTime;
	}

	public String getBookStatus() {
		return bookStatus;
	}

	public void setBookStatus(String bookStatus) {
		this.bookStatus = bookStatus;
	}

	public int getTripType() {
		return tripType;
	}

	public void setTripType(int tripType) {
		this.tripType = tripType;
	}

	public int getBookFlightId() {
		return bookFlightId;
	}

	public void setBookFlightId(int bookFlightId) {
		this.bookFlightId = bookFlightId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public LocalDateTime getBookFlightTime() {
		return bookFlightTime;
	}

	public void setBookFlightTime(LocalDateTime bookFlightTime) {
		this.bookFlightTime = bookFlightTime;
	}

	public LocalDateTime getBookingTime() {
		return bookingTime;
	}

	public void setBookingTime(LocalDateTime bookingTime) {
		this.bookingTime = bookingTime;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPnrNo() {
		return pnrNo;
	}

	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}

	public String getBookMeal() {
		return bookMeal;
	}

	public void setBookMeal(String bookMeal) {
		this.bookMeal = bookMeal;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerAge) {
		this.passengerName = passengerAge;
	}

	public String getPassengerGender() {
		return passengerGender;
	}

	public void setPassengerGender(String passengerGender) {
		this.passengerGender = passengerGender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "BookFlight [bookFlightId=" + bookFlightId + ", userName=" + userName + ", flightNo=" + flightNo
				+ ", bookFlightTime=" + bookFlightTime + ", bookingTime=" + bookingTime + ", emailId=" + emailId
				+ ", pnrNo=" + pnrNo + ", bookMeal=" + bookMeal + ", passengerName=" + passengerName
				+ ", passengerGender=" + passengerGender + ", age=" + age + ", tripType=" + tripType + ", bookStatus="
				+ bookStatus + "]";
	}
	
	
	
	
}
