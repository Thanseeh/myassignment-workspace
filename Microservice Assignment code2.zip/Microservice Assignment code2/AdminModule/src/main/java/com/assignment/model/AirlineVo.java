package com.assignment.model;


public class AirlineVo {
	
	private int airlineId;
	
	private String airlineName;
	
	private String airlineLogo;
	
	private int blockStatus;
	
	

	public AirlineVo(int airlineId, String airlineName, String airlineLogo, int blockStatus) {
		super();
		this.airlineId = airlineId;
		this.airlineName = airlineName;
		this.airlineLogo = airlineLogo;
		this.blockStatus = blockStatus;
	}

	public int getAirlineId() {
		return airlineId;
	}

	public void setAirlineId(int airlineId) {
		this.airlineId = airlineId;
	}

	public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	public String getAirlineLogo() {
		return airlineLogo;
	}

	public void setAirlineLogo(String airlineLogo) {
		this.airlineLogo = airlineLogo;
	}

	public int getBlockStatus() {
		return blockStatus;
	}

	public void setBlockStatus(int blockStatus) {
		this.blockStatus = blockStatus;
	}

	@Override
	public String toString() {
		return "AirlineVo [airlineId=" + airlineId + ", airlineName=" + airlineName + ", airlineLogo=" + airlineLogo
				+ ", blockStatus=" + blockStatus + "]";
	}
	
	
	
}
