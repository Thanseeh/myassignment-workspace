package com.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.entity.Flight;
import com.assignment.model.FlightVo;
import com.assignment.service.FlightService;

@RestController
@RequestMapping("/api/v1.0/flight/user")
public class CommunicationController {


	@Autowired
	FlightService flightService;
	
	@PostMapping("/search")
	public List<FlightVo> searchFlight(@RequestBody FlightVo bookFlight)  {
		return flightService.findByFlightDeatils(bookFlight);
	}
	
	@GetMapping("/getDetails/{flightId}")
	public FlightVo getFlightDetails(@PathVariable("flightId") int flightId)  {
		return flightService.getFlightDetailsById(flightId);
	}
}
