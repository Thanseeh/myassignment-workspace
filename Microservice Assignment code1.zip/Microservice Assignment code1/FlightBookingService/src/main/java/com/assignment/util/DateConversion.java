package com.assignment.util;

import java.time.Duration;
import java.time.LocalDateTime;

public class DateConversion {

	public static long findDifferenceOfDate(LocalDateTime bookFlightTime) {
		LocalDateTime currentTime = LocalDateTime.now();
		Duration diff = Duration.between(currentTime, bookFlightTime);
		System.out.println("Days: " + diff.toDays());
		return diff.toDays();
	}
	
	
}
