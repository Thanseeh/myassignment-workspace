package com.assignment.model;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;

import org.springframework.lang.NonNull;

import com.fasterxml.jackson.annotation.JsonFormat;


public class BookFlightVo {
	
	
	private String userName;
	
	private String flightNo;
	
//	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",shape = JsonFormat.Shape.STRING, timezone = "GMT+8")
	
	private String bookFlightFrom;
	
	private String bookFlightTo;
	
	
	private LocalDateTime bookFlightTime;
	
	private LocalDateTime bookFlightDestinationTime;
		
	private String emailId;
	
	private String pnrNo;

	private int bookMeal;
	//value 0 then one way otherwise 2 way
	private int tripType;
	
	private List<PassengerVo> passengers;


	public String getBookFlightFrom() {
		return bookFlightFrom;
	}

	public void setBookFlightFrom(String bookFlightFrom) {
		this.bookFlightFrom = bookFlightFrom;
	}

	public String getBookFlightTo() {
		return bookFlightTo;
	}

	public void setBookFlightTo(String bookFlightTo) {
		this.bookFlightTo = bookFlightTo;
	}

	public LocalDateTime getBookFlightDestinationTime() {
		return bookFlightDestinationTime;
	}

	public void setBookFlightDestinationTime(LocalDateTime bookFlightDestinationTime) {
		this.bookFlightDestinationTime = bookFlightDestinationTime;
	}

	
	
	public BookFlightVo(String userName, String flightNo, String bookFlightFrom, String bookFlightTo,
			LocalDateTime bookFlightTime, LocalDateTime bookFlightDestinationTime, String emailId, String pnrNo,
			int bookMeal, int tripType, List<PassengerVo> passengers) {
		super();
		this.userName = userName;
		this.flightNo = flightNo;
		this.bookFlightFrom = bookFlightFrom;
		this.bookFlightTo = bookFlightTo;
		this.bookFlightTime = bookFlightTime;
		this.bookFlightDestinationTime = bookFlightDestinationTime;
		this.emailId = emailId;
		this.pnrNo = pnrNo;
		this.bookMeal = bookMeal;
		this.tripType = tripType;
		this.passengers = passengers;
	}

//	public BookFlightVo(String userName, String flightNo, LocalDateTime bookFlightTime, String emailId, String pnrNo,
//			int bookMeal, int tripType, List<PassengerVo> passengers) {
//		super();
//		this.userName = userName;
//		this.flightNo = flightNo;
//		this.bookFlightTime = bookFlightTime;
//		this.emailId = emailId;
//		this.pnrNo = pnrNo;
//		this.bookMeal = bookMeal;
//		this.tripType = tripType;
//		this.passengers = passengers;
//	}

	@Override
	public String toString() {
		return "BookFlightVo [userName=" + userName + ", flightNo=" + flightNo + ", bookFlightFrom=" + bookFlightFrom
				+ ", bookFlightTo=" + bookFlightTo + ", bookFlightTime=" + bookFlightTime
				+ ", bookFlightDestinationTime=" + bookFlightDestinationTime + ", emailId=" + emailId + ", pnrNo="
				+ pnrNo + ", bookMeal=" + bookMeal + ", tripType=" + tripType + ", passengers=" + passengers + "]";
	}

	public int getTripType() {
		return tripType;
	}

	public void setTripType(int tripType) {
		this.tripType = tripType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public LocalDateTime getBookFlightTime() {
		return bookFlightTime;
	}

	public void setBookFlightTime(LocalDateTime bookFlightTime) {
		this.bookFlightTime = bookFlightTime;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPnrNo() {
		return pnrNo;
	}

	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}

	public int getBookMeal() {
		return bookMeal;
	}

	public void setBookMeal(int bookMeal) {
		this.bookMeal = bookMeal;
	}

	public List<PassengerVo> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<PassengerVo> passengers) {
		this.passengers = passengers;
	}
	
	
	
	
}
