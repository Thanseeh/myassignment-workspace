package com.assignment.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.assignment.model.BookFlightVo;
import com.assignment.model.FlightVo;
import com.assignment.service.UserService;

@RestController
@RequestMapping("/api/v1.0/flight/user")
public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	RestTemplate restTemplate;

	/*
	 * http://localhost:8L080/api/v1.0/flight/user/search
	 */
	@PostMapping("/search")
	public List<FlightVo> findBy(@RequestBody FlightVo bookFlight) {
		// find all flights from database -> admin-service

		String url = "http://adminservice/api/v1.0/flight/user/search";
		System.out.println(bookFlight);
		HttpMethod method = HttpMethod.POST;
//        HttpHeaders headers = new HttpHeaders();
		HttpEntity<?> requestEntity = new HttpEntity<>(bookFlight);
		ParameterizedTypeReference<List<FlightVo>> responseType = new ParameterizedTypeReference<List<FlightVo>>() {
		};

		ResponseEntity<List<FlightVo>> res = restTemplate.exchange(url, method, requestEntity, responseType);
		System.out.println("printing body");
		System.out.println(res.getBody());
		return res.getBody();
//		return null;
//		return userService.findByFlightDeatils(bookFlight);
	}

	/*
	 * http://localhost:8080/api/v1.0/flight/user/ticket/{pnr}
	 */
	@GetMapping("/ticket/{pnr}")
	public void viewHistoryViaPnr(@PathVariable String pnrNo) {
		userService.findByPnrNo(pnrNo);
	}

	/*
	 * http://localhost:8080/api/v1.0/flight/user/booking/history/{emailId}
	 */
	@GetMapping("/booking/history/{emailId}")
	public void viewHistory(@PathVariable String emailId) {
		userService.findByEmailId(emailId);
	}

	/*
	 * http://localhost:8080/api/v1.0/flight/user/booking/{flightId}
	 */
	@PostMapping("/booking/{flightId}")
	public void addFlightBooking(@RequestBody BookFlightVo bookFlight, @PathVariable("flightId") int flightId) {
		String url = "http://adminservice/api/v1.0/flight/user/getDetails/{flightId}";
		System.out.println(bookFlight);
		HttpMethod method = HttpMethod.GET;
		HttpEntity<?> requestEntity = new HttpEntity<>(null, null);
		ParameterizedTypeReference<FlightVo> responseType = new ParameterizedTypeReference<FlightVo>() {
		};

		ResponseEntity<FlightVo> res = restTemplate.exchange(url, method, requestEntity, responseType);
		System.out.println("printing response" + res.getBody());
		FlightVo body = res.getBody();
		bookFlight.setFlightNo(body.getFlightNumber());
		bookFlight.setBookFlightTime(body.getEndDate());
		bookFlight.setBookFlightFrom(body.getFromPlace());
		bookFlight.setBookFlightDestinationTime(body.getStartDate());
		bookFlight.setBookFlightTo(body.getToPlace());
		userService.addFlightBooking(bookFlight);
	}

	/*
	 * http://localhost:8080/api/v1.0/flight/user/booking/cancel/{pnrNo}
	 */
	@DeleteMapping("/booking/cancel/{pnrNo}")
	public void deleteFlightBooking(@PathVariable String pnr) {
		userService.deleteFlightBooking(pnr);
	}

}
