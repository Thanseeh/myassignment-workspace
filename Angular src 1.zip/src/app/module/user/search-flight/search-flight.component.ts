import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FlightVo } from 'src/app/models/flight-vo.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-search-flight',
  templateUrl: './search-flight.component.html',
  styleUrls: ['./search-flight.component.scss']
})
export class SearchFlightComponent implements OnInit {

  searchForm:FormGroup;
  flights:FlightVo[]=[];
  message:string='Please enter the values to search';

  constructor(private userService:UserService) { 
    this.searchForm = new FormGroup({
      fromPlace: new FormControl(""),
      toPlace: new FormControl(""),
      startDate: new FormControl(""),
      endDate: new FormControl("")
    });
  }

  ngOnInit(): void {
  }

  loadFlightDetails(){
    console.log(this.searchForm.value);
    this.userService.viewFlights(this.searchForm.value).subscribe({
      next: (res:any) => {
        console.log("airlines are fetched")
        this.flights = res;
        console.log(this.flights)
        if(this.flights.length==0)
          this.message = "NO FLIGHTS FOUND!!!";
      },
      error: (err) => {
        console.log("something bad happened")
        console.log(err)
      }
    })
  }

}
