import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { BookFlightVo } from 'src/app/models/book-flight-vo.model';
import { FlightVo } from 'src/app/models/flight-vo.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.scss']
})
export class ViewDetailsComponent implements OnInit {

  searchForm: FormGroup;
  histories: string[] = ['', 'pnr no', 'emailid'];
  selectedValue: string = '';
  enablePnr: boolean = false;
  enableEmailId: boolean = false;
  flights: FlightVo[] = [];
  bookFlight: BookFlightVo[] = [];
  message: string = 'Please enter the values to search';

  constructor(private userService: UserService) {
    this.searchForm = new FormGroup({
      emailId: new FormControl(""),
      pnrNo: new FormControl(""),
      typeOfSearch: new FormControl("")
    });
  }
  onChangeTags() {
    console.log(this.searchForm.value['typeOfSearch'])
    if (this.searchForm.value['typeOfSearch'] == 'PNR No') {
      this.enablePnr = true;
      this.enableEmailId = false;
    } else if (this.searchForm.value['typeOfSearch'] == 'Email Id') {
      this.enablePnr = false;
      this.enableEmailId = true;
      this.selectedValue = 'EMAILID';
    } else {
      this.enablePnr = false;
      this.enableEmailId = false;
    }


  }

  ngOnInit(): void {
  }

  cancelBooking() {
    let pnrNo = this.bookFlight.length > 0 ? this.bookFlight[0].pnrNo : '';
    if (pnrNo != '') {
      this.userService.cancelBooking(pnrNo).subscribe({
        next: (res: any) => {
          console.log("airlines are fetched")
          this.bookFlight = [];
          if (res == true) {
            this.message = "BOOKING CANCELED SUCCESSFULLY";
        } else {
            this.message = "BOOKING CANNOT BE CANCELLED";
        }
          // this.bookFlight = res;
          // console.log(this.bookFlight)

        },
        error: (err) => {
          console.log("something bad happened")
          console.log(err)
        }
      })
    }
  }

  loadBookingDetails() {
    console.log(this.searchForm.value);
    if (this.searchForm.value['typeOfSearch'] == 'Email Id' && this.searchForm.value['emailId'] != undefined) {
      this.userService.viewHistoryByEmailId(this.searchForm.value['emailId']).subscribe({
        next: (res: any) => {
          console.log("airlines are fetched")
          this.bookFlight = res;
          console.log(this.bookFlight)
          if (this.bookFlight.length == 0)
            this.message = "NO BOOKINGS FOUND!!!";
        },
        error: (err) => {
          console.log("something bad happened")
          console.log(err)
        }
      })
    } else if (this.searchForm.value['typeOfSearch'] == 'PNR No' && this.searchForm.value['pnrNo'] != undefined) {
      this.userService.viewHistoryByPNR(this.searchForm.value['pnrNo']).subscribe({
        next: (res: any) => {
          console.log("airlines are fetched")
          this.bookFlight = res;
          console.log(this.bookFlight)
          if (this.bookFlight.length == 0)
            this.message = "NO BOOKINGS FOUND!!!";
        },
        error: (err) => {
          console.log("something bad happened")
          console.log(err)
        }
      })
    } else {
      this.message = "Please enter coreect details!!!";
    }

  }




}
