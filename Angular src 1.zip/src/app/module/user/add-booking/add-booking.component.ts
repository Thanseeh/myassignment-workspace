import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-add-booking',
  templateUrl: './add-booking.component.html',
  styleUrls: ['./add-booking.component.scss']
})
export class AddBookingComponent implements OnInit {

  bookFlightForm: FormGroup;
  flightId: number = 0;
  flightNumber: string = '';
  totalCost: number = 0;
  totalCost1: number = 0;
  meals: string[] = ['none', 'veg', 'non-veg'];
  constructor(private route:Router,private fb: FormBuilder, private activatedRoute: ActivatedRoute, private userService: UserService) {
    this.bookFlightForm = this.fb.group({
      flightNo: new FormControl(""),
      airlineName: new FormControl(""),
      bookFlightFrom: new FormControl(""),
      bookFlightTo: new FormControl(""),
      bookFlightTime: new FormControl(""),
      bookFlightDestinationTime: new FormControl(""),
      userName: new FormControl("", [
        Validators.required
      ]),
      emailId: new FormControl("", [
        Validators.required
      ]),
      bookMeal: new FormControl(""),
      tripType: new FormControl(""),
      passengers: this.fb.array([])
      // employees: this.fb.array([])
    });

    this.activatedRoute.params.subscribe((params) => {
      this.flightId = params['flightId'];
      this.flightNumber = params['flightNumber'];
      this.totalCost = params['totalCost'];
      this.totalCost1 = params['totalCost'];
    });
    this.addNewPassenger();
  }

  ngOnInit() {

  }

  newPassenger(): FormGroup {
    return this.fb.group({
      passengerName: new FormControl("", [
        Validators.required
      ]),
      passengerGender: new FormControl("", [
        Validators.required
      ]),
      age: new FormControl("", [
        Validators.required
      ])
    });
  }

  getPassengers(): FormArray {
    return this.bookFlightForm.get('passengers') as FormArray;
  }

  addNewPassenger() {
    this.getPassengers().push(this.newPassenger());
    this.totalCost = this.totalCost1 * this.getPassengers().length;
  }

  removeNewPassenger(bookIndex: number) {
    this.getPassengers().removeAt(bookIndex);
    this.totalCost = this.totalCost1 * this.getPassengers().length;
  }
  addBooking() {
    console.log(this.bookFlightForm.value);
    this.userService.addBooking(this.bookFlightForm.value, this.flightId).subscribe({
      next: (res: any) => {
        console.log("fetched data")
        console.log(res);
        console.log(res['pnrNo']);
        if(res['pnrNo'] != undefined)
           this.route.navigate(['/user/pnrCreated/',res['pnrNo']]);
      }
    });
  }
  // addEmployeeSkill(empIndex: number) {
  //   this.employeeSkills(empIndex).push(this.newSkill());
  // }

  // removeEmployeeSkill(empIndex: number, skillIndex: number) {
  //   this.employeeSkills(empIndex).removeAt(skillIndex);
  // }

  onSubmit() {
    console.log(this.bookFlightForm.value);
  }

}
