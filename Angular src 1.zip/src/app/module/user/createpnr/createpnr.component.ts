import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-createpnr',
  templateUrl: './createpnr.component.html',
  styleUrls: ['./createpnr.component.scss']
})
export class CreatepnrComponent implements OnInit {

  
  message:string='Please enter the values to search';
  pnrNo:string = '';
  constructor(private router:ActivatedRoute) { 
    this.router.params.subscribe((params)=>{
      this.pnrNo = params['pnrNo'];
    });
  }

  ngOnInit(): void {
  }

 

}
