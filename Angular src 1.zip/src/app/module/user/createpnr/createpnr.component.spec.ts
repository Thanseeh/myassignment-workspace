import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatepnrComponent } from './createpnr.component';

describe('CreatepnrComponent', () => {
  let component: CreatepnrComponent;
  let fixture: ComponentFixture<CreatepnrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreatepnrComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatepnrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
