import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddBookingComponent } from './add-booking/add-booking.component';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './user.component';
import { UserheaderComponent } from './userheader/userheader.component';
import { CreatepnrComponent } from './createpnr/createpnr.component';


const routes: Routes = [{
  path: "", component: UserComponent,
  children: [
    { path: "search", component: SearchFlightComponent },
    { path: "viewHistory", component: ViewDetailsComponent },
    { path: "booking/:flightId/:totalCost/:flightNumber", component: AddBookingComponent },
    { path: "pnrCreated/:pnrNo", component: CreatepnrComponent }
  ]
}
]


@NgModule({
  declarations: [
    UserComponent,
    AddBookingComponent,
    SearchFlightComponent,
    ViewDetailsComponent,
    UserheaderComponent,
    CreatepnrComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)
  ]
})
export class UserModule { }
