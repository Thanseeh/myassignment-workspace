import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AirlineVo } from 'src/app/models/airline-vo.model';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-add-flight',
  templateUrl: './add-flight.component.html',
  styleUrls: ['./add-flight.component.scss']
})
export class AddFlightComponent implements OnInit {

  flightForm: FormGroup;
  airlines: AirlineVo[] = [];
  schedule:string[] =['weekends','weekdays','all days'];

  constructor(private adminService: AdminService) {
    this.flightForm = new FormGroup({
      airlineName: new FormControl("", [
        Validators.required
      ]),
      flightNumber: new FormControl("", [
        Validators.required
      ]),
      fromPlace: new FormControl("", [
        Validators.required
      ]),
      toPlace: new FormControl("", [
        Validators.required
      ]),
      startDate: new FormControl("", [
        Validators.required
      ]),
      endDate: new FormControl("", [
        Validators.required
      ]),
      businessSeat: new FormControl("", [
        Validators.required
      ]),
      nonBusinessSeat: new FormControl("", [
        Validators.required
      ]),
      noOfRows: new FormControl("", [
        Validators.required
      ]),
      scheduleDays: new FormControl("", [
        Validators.required
      ]),
      totalCost: new FormControl("", [
        Validators.required
      ])

    });
  }

  ngOnInit(): void {
    this.loadAirlines();
  }

  loadAirlines() {
    this.adminService.viewAirline().subscribe({
      next: (res: any) => {
        console.log("airlines are fetched")
        // this.airlines = res;
        console.log(res);
        this.airlines = res;
        console.log(this.airlines)
      },
      error: (err) => {
        console.log("something bad happened")
        console.log(err)
      }
    })
  }

  addFlight() {
    console.log("adsdasdsa")
    console.log(this.flightForm.value)
    // let schedule = this.flightForm.value['scheduleDays'];
    // if (schedule == '') {
    //   \
    // } else {
    //   airline['blockStatus'] = 0;
    // }
    // console.log(airline)
    this.adminService.addFlight(this.flightForm.value).subscribe({
      next: (res: any) => {
        console.log("fetched data")
        console.log(res);
      }
    });
  }
}
