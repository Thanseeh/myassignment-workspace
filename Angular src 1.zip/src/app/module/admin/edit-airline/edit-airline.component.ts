import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AirlineVo } from 'src/app/models/airline-vo.model';
import { AdminService } from 'src/app/services/admin.service';
import { AirlineViewComponent } from '../airline-view/airline-view.component';

@Component({
  selector: 'app-edit-airline',
  templateUrl: './edit-airline.component.html',
  styleUrls: ['./edit-airline.component.scss']
})
export class EditAirlineComponent implements OnInit {

  airlineForm:FormGroup;
  airline:AirlineVo = {airlineId: 0,airlineName:'',airlineLogo:'',blockStatus:0};

  constructor(private adminService:AdminService,private activatedRoute:ActivatedRoute) {
    this.airlineForm = new FormGroup({
      airlineName: new FormControl({value: '', disabled: true}),
      blockStatus: new FormControl('')
    });
    this.activatedRoute.params.subscribe((params)=>{
      // console.log("param changed");
     
      this.airline.airlineId = params['airlineId'];
      this.airline.airlineName = params['airlineName'];
      this.airline.blockStatus = params['blockStatus'];
      // this.loadFlightDetails();
    });
   }

  ngOnInit(): void {
  
  }

  editAirline(){
    console.log(this.airlineForm.value)
    let airline = this.airlineForm.value;
    if(airline['blockStatus']== true){
      airline['blockStatus'] = 1;
    }else{
      airline['blockStatus'] = 0;
    }
    console.log(airline)
    this.adminService.editAirline(airline).subscribe({
      next: (res: any) => {
        console.log("edit airline")
       console.log(res);
      }
    });
  }

}
