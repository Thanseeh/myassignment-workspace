import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { LoginComponent } from './login/login.component';
import { AirlineViewComponent } from './airline-view/airline-view.component';
import { FlightViewComponent } from './flight-view/flight-view.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { LoginCheckGuard } from 'src/app/guards/login-check.guard';
import { AddAirlineComponent } from './add-airline/add-airline.component';
import { EditAirlineComponent } from './edit-airline/edit-airline.component';
import { AddFlightComponent } from './add-flight/add-flight.component';
import { EditFlightComponent } from './edit-flight/edit-flight.component';
import { AdminHeaderComponent } from './admin-header/admin-header.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';


const routes: Routes = [{
  path: "", component: AdminComponent,
  children: [
    { path: "login", component: LoginComponent },
    { path: "airline", component: AirlineViewComponent ,canActivate: [LoginCheckGuard]},
    { path: "adminHome/:username", component: AdminHomeComponent ,canActivate: [LoginCheckGuard]},
    { path: "addAirline", component: AddAirlineComponent ,canActivate: [LoginCheckGuard]},
    { path: "addFlight", component: AddFlightComponent ,canActivate: [LoginCheckGuard]},
    { path: "editAirline/:airlineId/:airlineName/:blockStatus", component: EditAirlineComponent ,canActivate: [LoginCheckGuard]},
    { path: "editFlight/:flightId", component: EditFlightComponent ,canActivate: [LoginCheckGuard]},
    { path: "flights/:airlineName", component: FlightViewComponent ,canActivate: [LoginCheckGuard]},
    { path: "**", redirectTo: "login" }
  ]
}
]

@NgModule({
  declarations: [
    AdminComponent,
    LoginComponent,
    AirlineViewComponent,
    FlightViewComponent,
    AddAirlineComponent,
    EditAirlineComponent,
    AddFlightComponent,
    EditFlightComponent,
    AdminHeaderComponent,
    AdminHomeComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)
  ]
})
export class AdminModule { }
