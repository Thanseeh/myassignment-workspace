import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AirlineVo } from 'src/app/models/airline-vo.model';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-edit-flight',
  templateUrl: './edit-flight.component.html',
  styleUrls: ['./edit-flight.component.scss']
})
export class EditFlightComponent implements OnInit {

  flightForm: FormGroup;
  airlines: AirlineVo[] = [];
  schedule:string[] =['weekends','weekdays','all days'];
  flightId:number = 0;

  constructor(private adminService: AdminService,private activatedRoute:ActivatedRoute) {
    this.flightForm = new FormGroup({
      flightId:new FormControl(""),
      airlineName: new FormControl({value:"",disabled: true}, [
        Validators.nullValidator
      ]),
      flightNumber: new FormControl({value:"",disabled: true}, [
        Validators.nullValidator
      ]),
      fromPlace: new FormControl("", [
        Validators.nullValidator
      ]),
      toPlace: new FormControl("", [
        Validators.nullValidator
      ]),
      startDate: new FormControl("", [
        Validators.nullValidator
      ]),
      endDate: new FormControl("", [
        Validators.nullValidator
      ]),
      businessSeat: new FormControl("", [
        Validators.nullValidator
      ]),
      nonBusinessSeat: new FormControl("", [
        Validators.nullValidator
      ]),
      noOfRows: new FormControl("", [
        Validators.nullValidator
      ]),
      scheduleDays: new FormControl("", [
        Validators.nullValidator
      ]),
      totalCost: new FormControl("", [
        Validators.nullValidator
      ]),
      meals:new FormControl("")
    });
    this.activatedRoute.params.subscribe((params)=>{
      // console.log("param changed");  
      this.flightId = params['flightId'];
      this.loadFlightDetails();
      // this.loadFlightDetails();
    });
  }

  ngOnInit(): void {
  }

  loadFlightDetails() {
    this.adminService.viewFlightById(this.flightId).subscribe({
      next: (res: any) => {
        console.log("airlines are fetched")
        // this.airlines = res;
        console.log(res);
        this.flightForm.setValue(res);
      },
      error: (err) => {
        console.log("something bad happened")
        console.log(err)
      }
    })
  }



  editFlight() {
    console.log("adsdasdsa")
    console.log(this.flightForm.value)

    this.adminService.editFlight(this.flightForm.value,this.flightId).subscribe({
      next: (res: any) => {
        console.log("fetched data")
        console.log(res);
      }
    });
  }

}
