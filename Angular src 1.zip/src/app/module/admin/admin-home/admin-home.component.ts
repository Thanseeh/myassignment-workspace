import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.scss']
})
export class AdminHomeComponent implements OnInit {

  username:string='';

  constructor(private activatedRoute:ActivatedRoute,private adminService:AdminService) {
    this.activatedRoute.params.subscribe((params)=>{
      // console.log("param changed");
      console.log(params);
      this.username = params['username'];
      this.adminService.user= this.username;
    })
   }

  ngOnInit(): void {
  }

}
