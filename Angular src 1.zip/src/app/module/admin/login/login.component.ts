import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;

  messageSts:string|null= null;

  constructor(private adminService: AdminService, private router: Router) {
    this.loginForm = new FormGroup({
      username: new FormControl("", [
        // Validators.pattern(""),
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(8)
      ]),
      password: new FormControl("", [
        // Validators.pattern(""),
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(8)
      ])
    });
  }

  ngOnInit(): void {
  }

  getLogin() {
    console.log(this.loginForm.value)
    if (!!this.loginForm.value) {
      this.adminService.loginCheck(this.loginForm.value).subscribe({
        next: (res: any) => {
          console.log(res);
          if(!!res['token']){
            this.messageSts=null;
            localStorage.setItem('TOKEN',res['token']);
            this.adminService.user= this.loginForm.value['username'];
            this.router.navigate(["/admin/adminHome",this.loginForm.value['username']]);
          }else  if(!!res['message']){
              this.messageSts = res['message'];
          }else{
            this.messageSts = "UNKNOWN ERROR";
          }
        },
        error: (err) => {
          console.log("something bad happened")
          console.log(err)
        }
      })
    } else {
      console.log("Invalid user")
    }
  }

}
