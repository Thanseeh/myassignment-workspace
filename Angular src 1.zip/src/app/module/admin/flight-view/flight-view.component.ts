import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { FlightVo } from 'src/app/models/flight-vo.model';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-flight-view',
  templateUrl: './flight-view.component.html',
  styleUrls: ['./flight-view.component.scss']
})
export class FlightViewComponent implements OnInit {

  flights:FlightVo[] = [];
  airlineName:string = '';

  constructor(private activatedRoute:ActivatedRoute,private adminService:AdminService) { 
    this.activatedRoute.params.subscribe((params)=>{
      // console.log("param changed");
      console.log(params);
      this.airlineName = params['airlineName'];
      this.loadFlightDetails();
    });
  }

  ngOnInit(): void {
  }

  loadFlightDetails(){
    this.adminService.viewFlights(this.airlineName).subscribe({
      next: (res:any) => {
        console.log("airlines are fetched")
        this.flights = res;
        console.log(this.flights)
      },
      error: (err) => {
        console.log("something bad happened")
        console.log(err)
      }
    })
  }

  deleteFlight(flightId:number){
    this.adminService.deleteFlight(flightId).subscribe({
      next: (res:any) => {
        this.loadFlightDetails();
        console.log("airlines are fetched")
        // this.flights = res;
        // console.log(this.flights)
      },
      error: (err) => {
        console.log("something bad happened")
        console.log(err)
      }
    })
  }

}
