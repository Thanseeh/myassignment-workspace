import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AirlineVo } from 'src/app/models/airline-vo.model';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-airline-view',
  templateUrl: './airline-view.component.html',
  styleUrls: ['./airline-view.component.scss']
})
export class AirlineViewComponent implements OnInit {

  airlines:AirlineVo[] = [];


  constructor(private adminService:AdminService) { 
  }

  ngOnInit(): void {
    this.loadAirlineDetails();
  }

  loadAirlineDetails(){
    this.adminService.viewAirline().subscribe({
      next: (res:any) => {
        console.log("airlines are fetched")
        this.airlines = res;
        console.log(this.airlines)
      },
      error: (err) => {
        console.log("something bad happened")
        console.log(err)
      }
    })
  }

  

}
