import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-add-airline',
  templateUrl: './add-airline.component.html',
  styleUrls: ['./add-airline.component.scss']
})
export class AddAirlineComponent implements OnInit {

  airlineForm:FormGroup;

  constructor(private adminService:AdminService) {
    this.airlineForm = new FormGroup({
      airlineName: new FormControl("", [
        // Validators.pattern(""),
        Validators.required
      ]),
      blockStatus: new FormControl("")
    });
   }

  ngOnInit(): void {
  }

  addAirline(){
    console.log(this.airlineForm.value)
    let airline = this.airlineForm.value;
    if(airline['blockStatus']== true){
      airline['blockStatus'] = 1;
    }else{
      airline['blockStatus'] = 0;
    }
    console.log(airline)
    this.adminService.addAirline(airline).subscribe({
      next: (res: any) => {
        console.log("fetched data")
       console.log(res);
      }
    });
  }

}
