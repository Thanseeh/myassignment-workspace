export interface PassengerVo {

    passengerName:string
	
	passengerGender:string;
	
	age:number;


}
