export interface FlightVo {

	airlineId:number;
    flightId:number;
	
	airlineName:string;
	
	fromPlace:string;
	
	toPlace:string;
	
    startDate:Date;
	
    endDate:Date;
	
	flightNumber:string;
	
	businessSeat:number;
	
	nonBusinessSeat:number;
	
	noOfRows:number;
	
	totalCost:number;
	
	meals:string;
	
	scheduleDays:string;
}
