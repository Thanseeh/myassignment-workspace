export interface BookFlightVo {

    flightId: number;

    airlineName: string;

    fromPlace: string;

    toPlace: string;

    startDate: Date;

    endDate: Date;

    flightNumber: string;

    businessSeat: number;

    nonBusinessSeat: number;

    noOfRows: number;

    totalCost: number;

    meals: string;

    scheduleDays: string;
    passengerName: string

    passengerGender: string;

    age: number;
    bookFlightDestinationTime:Date;
    bookFlightFrom:string;
    bookFlightTo:string;
    bookFlightTime:Date;
    bookingTime:Date;
    pnrNo:string;
    emailId:string;
    userName:string;
    flightNo:string;
    bookStatus:string;
    flightAirlineName:string;
    bookingCost:number;

}
