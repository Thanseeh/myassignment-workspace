export interface ErrorResponse {

	message: string;
	now: Date;
}
