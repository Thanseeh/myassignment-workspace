import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { FlightVo } from '../models/flight-vo.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private serverIp: string = "http://localhost:8989/";

  constructor(private http: HttpClient) { }

  viewFlights(flight:FlightVo) {
    const headers = { 'content-type': 'application/json' }
    return this.http.post(this.serverIp + "user/api/v1.0/flight/user/search", JSON.stringify(flight), { 'headers': headers });
  }

  viewHistoryByPNR(pnrNo:string) {
    console.log('pnr No'+pnrNo)
    const headers = { 'content-type': 'application/json' }
    return this.http.get(this.serverIp + "user/api/v1.0/flight/user/ticket/"+pnrNo, { 'headers': headers });
  }

  viewHistoryByEmailId(emailId:string) {
    const headers = { 'content-type': 'application/json' }
    return this.http.get(this.serverIp + "user/api/v1.0/flight/user/booking/history/"+emailId, { 'headers': headers });
  }

  cancelBooking(pnrNo:string) {
    const headers = { 'content-type': 'application/json' }
    return this.http.delete(this.serverIp + "user/api/v1.0/flight/user/booking/cancel/"+pnrNo, { 'headers': headers });
  }

  addBooking(bookFlight: any,flightId:number) {
    console.log("adding airlines")
    const headers = {
      'content-type': 'application/json'
    };
    console.log(headers)
    const body = JSON.stringify(bookFlight);
    console.log(body)
    return this.http.post(this.serverIp + "/user/api/v1.0/flight/user/booking/"+flightId, body, { 'headers': headers });
  }

}
