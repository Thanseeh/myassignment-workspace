import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AirlineVo } from '../models/airline-vo.model';
import { FlightVo } from '../models/flight-vo.model';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient) { }

  private serverIp: string = "http://localhost:8989/";

  private userDetails = {
    userName: '',
    valid: false
  };

  set user(name: string) {
    this.userDetails.valid = !!name;
    this.userDetails.userName = name;
  }

  get user() {
    return this.userDetails.userName;
  }

  get isValid() {
    return this.userDetails.valid;
  }
  loginCheck(userDeatils: any) {
    console.log("checking login")
    const headers = { 'content-type': 'application/json' }
    const body = JSON.stringify(userDeatils);
    console.log(body)
    return this.http.post(this.serverIp + "admin/authenticate", body, { 'headers': headers });
  }

  viewAirline() {
    console.log("fetching airlines")
    // const headers = {
    //   'Authorization': 'Bearer ' + localStorage.getItem("TOKEN"),
    //   'content-type': 'application/json',
    //   'Access-Control-Allow-Origin': '*'
    // };
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': ' POST, GET, OPTIONS, DELETE',
      'Access-Control-Max-Age': ' 3600',
      'Access-Control-Allow-Headers': 'Content-Type, Accept, X-Requested-With, remember-me',
      'Authorization':
        'Bearer ' + localStorage.getItem("TOKEN")
    });
    console.log(headers)
    return this.http.get(this.serverIp + "admin/api/v1.0/flight/admin/airline", { 'headers': headers });
  }


  viewFlights(airlineName:string) {
    console.log("fetching flights")

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': ' POST, GET, OPTIONS, DELETE',
      'Access-Control-Max-Age': ' 3600',
      'Access-Control-Allow-Headers': 'Content-Type, Accept, X-Requested-With, remember-me',
      'Authorization':
        'Bearer ' + localStorage.getItem("TOKEN")
    });
    console.log(headers)
    return this.http.get(this.serverIp + "admin/api/v1.0/flight/admin/airline/inventory/viewByAirline/"+airlineName, { 'headers': headers });
  }

  addAirline(airline: AirlineVo) {
    console.log("adding airlines")
    const headers = {
      "Authorization": "Bearer " + localStorage.getItem("TOKEN"),
      'content-type': 'application/json'
    };
    console.log(headers)
    const body = JSON.stringify(airline);
    console.log(body)
    return this.http.post(this.serverIp + "admin/api/v1.0/flight/admin/airline/register", body, { 'headers': headers });
  }

  editAirline(airline: AirlineVo) {
    console.log("adding airlines")
    const headers = {
      "Authorization": "Bearer " + localStorage.getItem("TOKEN"),
      'content-type': 'application/json'
    };
    console.log(headers)
    const body = JSON.stringify(airline);
    console.log(body)
    return this.http.post(this.serverIp + "admin/api/v1.0/flight/admin/airline/block", body, { 'headers': headers });
  }

  viewFlightById(flightId:number){
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': ' POST, GET, OPTIONS, DELETE',
      'Access-Control-Max-Age': ' 3600',
      'Access-Control-Allow-Headers': 'Content-Type, Accept, X-Requested-With, remember-me',
      'Authorization':
        'Bearer ' + localStorage.getItem("TOKEN")
    });
    console.log(headers)
    return this.http.get(this.serverIp + "admin/api/v1.0/flight/admin/airline/inventory/"+flightId, { 'headers': headers });
  
  }

  editFlight(flight: FlightVo,flightId:number) {
    console.log("adding airlines")
    const headers = {
      "Authorization": "Bearer " + localStorage.getItem("TOKEN"),
      'content-type': 'application/json'
    };
    console.log(headers)
    const body = JSON.stringify(flight);
    console.log(body)
    return this.http.put(this.serverIp + "admin/api/v1.0/flight/admin/airline/inventory/update/"+flightId, body, { 'headers': headers });
  }

  deleteFlight(flightId:number) {
    console.log("adding airlines")
    const headers = {
      "Authorization": "Bearer " + localStorage.getItem("TOKEN"),
      'content-type': 'application/json'
    };
    console.log(headers)
    // const body = JSON.stringify(airline);
    // console.log(body)
    return this.http.delete(this.serverIp + "admin/api/v1.0/flight/admin/airline/inventory/delete/"+flightId, { 'headers': headers });
  }

  addFlight(flight: FlightVo) {
    console.log("adding flights")
    const headers = {
      "Authorization": "Bearer " + localStorage.getItem("TOKEN"),
      'content-type': 'application/json'
    };
    console.log(headers)
    const body = JSON.stringify(flight);
    console.log(body)
    return this.http.post(this.serverIp + "admin/api/v1.0/flight/admin/airline/inventory/add", body, { 'headers': headers });
  }


}
