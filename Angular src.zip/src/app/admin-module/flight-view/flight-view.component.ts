import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FlightVo } from 'src/app/models/flight-vo.model';

@Component({
  selector: 'app-flight-view',
  templateUrl: './flight-view.component.html',
  styleUrls: ['./flight-view.component.scss']
})
export class FlightViewComponent implements OnInit {

  flights:FlightVo[] = [];

  flightForm:FormGroup; 

  constructor() { 
    this.flightForm = new FormGroup({
      airlineName: new FormControl(""),
      blockStatus: new FormControl("")
    });
    
  }

  ngOnInit(): void {
  }

  addAirline(){
    console.log(this.flightForm.value)
    this.flights.push(this.flightForm.value);
  }

}
