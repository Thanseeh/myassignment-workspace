import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AirlineViewComponent } from './airline-view.component';

describe('AirlineViewComponent', () => {
  let component: AirlineViewComponent;
  let fixture: ComponentFixture<AirlineViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AirlineViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AirlineViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
