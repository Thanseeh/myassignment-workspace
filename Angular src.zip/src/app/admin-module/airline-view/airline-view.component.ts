import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AirlineVo } from 'src/app/models/airline-vo.model';

@Component({
  selector: 'app-airline-view',
  templateUrl: './airline-view.component.html',
  styleUrls: ['./airline-view.component.scss']
})
export class AirlineViewComponent implements OnInit {

  airlines:AirlineVo[] = [];

  airlineForm:FormGroup; 

  constructor() { 
    this.airlineForm = new FormGroup({
      airlineName: new FormControl(""),
      blockStatus: new FormControl("")
    });
    
  }

  ngOnInit(): void {
  }

  addAirline(){
    console.log(this.airlineForm.value)
    this.airlines.push(this.airlineForm.value);
  }

}
