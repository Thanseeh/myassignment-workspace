import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { AdminModuleComponent } from './admin-module/admin-module.component';
import { LoginComponent } from './admin-module/login/login.component';
import { AdminHomeComponent } from './admin-module/admin-home/admin-home.component';
import { AirlineViewComponent } from './admin-module/airline-view/airline-view.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ReactiveFormsModule } from '@angular/forms';
import { FlightViewComponent } from './admin-module/flight-view/flight-view.component';
import { UserModuleComponent } from './user-module/user-module.component';
import { SearchFlightComponent } from './user-module/search-flight/search-flight.component';
import { AddBookingComponent } from './user-module/add-booking/add-booking.component';
import { ViewDetailsComponent } from './user-module/view-details/view-details.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminModuleComponent,
    LoginComponent,
    AdminHomeComponent,
    AirlineViewComponent,
    HeaderComponent,
    FooterComponent,
    FlightViewComponent,
    UserModuleComponent,
    SearchFlightComponent,
    AddBookingComponent,
    ViewDetailsComponent
  ],
  imports: [
    BrowserModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
