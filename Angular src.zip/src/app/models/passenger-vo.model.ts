export interface PassengerVo {
}
