export interface BookFlightVo {
}
