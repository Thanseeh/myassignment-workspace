export interface FlightVo {

    flightId:number;
	
	airlineName:string;
	
	fromPlace:string;
	
	toPlace:string;
	
    startDate:Date;
	
    endDate:Date;
	
	flightNumber:string;
	
	businessSeat:number;
	
	nonBusinessSeat:number;
	
	noOfRows:number;
	
	ptotalCost:number;
	
	meals:string;
	
	scheduleDays:string;
}
