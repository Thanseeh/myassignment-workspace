export interface AirlineVo {

    airlineId:number;
	
	airlineName:string;
	
	airlineLogo:string;
	
	blockStatus:number;

}
