package com.assignment.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class FlightVo {
	
	private int flightId;
	
	private String airlineName;
	
	private String fromPlace;
	
	private String toPlace;
	
//	@JsonDeserialize(as = LocalDateTime.class)
	private LocalDateTime startDate;
	
//	@JsonDeserialize(as = LocalDateTime.class)
	private LocalDateTime endDate;
	
	private String flightNumber;
	
	private int businessSeat;
	
	private int nonBusinessSeat;
	
	private int noOfRows;
	
	private int totalCost;
	
	private String meals;
	
	private String scheduleDays;

	
	public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFromPlace() {
		return fromPlace;
	}

	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}

	public String getToPlace() {
		return toPlace;
	}

	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public int getBusinessSeat() {
		return businessSeat;
	}

	public void setBusinessSeat(int businessSeat) {
		this.businessSeat = businessSeat;
	}

	public int getNonBusinessSeat() {
		return nonBusinessSeat;
	}

	public void setNonBusinessSeat(int nonBusinessSeat) {
		this.nonBusinessSeat = nonBusinessSeat;
	}

	public int getNoOfRows() {
		return noOfRows;
	}

	public void setNoOfRows(int noOfRows) {
		this.noOfRows = noOfRows;
	}

	public int getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}

	public String getMeals() {
		return meals;
	}

	public void setMeals(String meals) {
		this.meals = meals;
	}

	public String getScheduleDays() {
		return scheduleDays;
	}

	public void setScheduleDays(String scheduleDays) {
		this.scheduleDays = scheduleDays;
	}

	@Override
	public String toString() {
		return "FlightVo [flightId=" + flightId + ", airlineName=" + airlineName + ", fromPlace=" + fromPlace
				+ ", toPlace=" + toPlace + ", startDate=" + startDate + ", endDate=" + endDate + ", flightNumber="
				+ flightNumber + ", businessSeat=" + businessSeat + ", nonBusinessSeat=" + nonBusinessSeat
				+ ", noOfRows=" + noOfRows + ", totalCost=" + totalCost + ", meals=" + meals + ", scheduleDays="
				+ scheduleDays + "]";
	}
	
	
}
