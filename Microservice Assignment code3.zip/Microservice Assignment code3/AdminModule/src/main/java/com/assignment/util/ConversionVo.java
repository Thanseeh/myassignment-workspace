package com.assignment.util;

import com.assignment.entity.Flight;
import com.assignment.model.FlightVo;

public class ConversionVo {
		
	public static FlightVo convertFlightToFlightVo(Flight flight) {
		FlightVo flightVo = new FlightVo();
		flightVo.setFlightId(flight.getAirlineId());
		flightVo.setAirlineName(flight.getAirlineName());
		flightVo.setBusinessSeat(flight.getBusinessSeat());
		flightVo.setEndDate(flight.getEndDate());
		flightVo.setFlightNumber(flight.getFlightNumber());
		flightVo.setFromPlace(flight.getFromPlace());
		flightVo.setMeals(flight.getMeals());
		flightVo.setNonBusinessSeat(flight.getNonBusinessSeat());
		flightVo.setNoOfRows(flight.getNoOfRows());
		flightVo.setScheduleDays(flight.getScheduleDays());
		flightVo.setStartDate(flight.getStartDate());
		flightVo.setToPlace(flight.getToPlace());
		flightVo.setTotalCost(flight.getTotalCost());
		return flightVo;
	}
	
	public static Flight convertFlightVoToFlight(FlightVo flightVo) {
		Flight flight = new Flight();
		flight.setAirlineName(flightVo.getAirlineName());
		flight.setBusinessSeat(flightVo.getBusinessSeat());
		flight.setEndDate(flightVo.getEndDate());
		flight.setFlightNumber(flightVo.getFlightNumber());
		flight.setFromPlace(flightVo.getFromPlace());
		flight.setToPlace(flightVo.getToPlace());
		flight.setMeals(flightVo.getMeals());
		flight.setNonBusinessSeat(flightVo.getNonBusinessSeat());
		flight.setNoOfRows(flightVo.getNoOfRows());
		flight.setScheduleDays(flightVo.getScheduleDays());
		flight.setStartDate(flightVo.getStartDate());
		flight.setTotalCost(flightVo.getTotalCost());
		return flight;
	}
}
