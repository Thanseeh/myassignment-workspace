package com.assignment.model;


public class PassengerVo {
		
	private String passengerName;
	
	private String passengerGender;
	
	private int age;

	public PassengerVo(String passengerAge, String passengerGender, int age) {
		super();
		this.passengerName = passengerAge;
		this.passengerGender = passengerGender;
		this.age = age;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerAge) {
		this.passengerName = passengerAge;
	}

	public String getPassengerGender() {
		return passengerGender;
	}

	public void setPassengerGender(String passengerGender) {
		this.passengerGender = passengerGender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "PassengerVo [passengerAge=" + passengerName + ", passengerGender=" + passengerGender + ", age=" + age
				+ "]";
	}
	
	
}
