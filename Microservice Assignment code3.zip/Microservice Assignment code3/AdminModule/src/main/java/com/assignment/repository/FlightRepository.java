package com.assignment.repository;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.assignment.entity.Flight;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Integer>{

	List<Flight> findByAirlineName(String airlineName);

	List<Flight> findByAirlineNameAndFlightNumber(String airlineName, String flightNumber);

//	@Query("SELECT DISTINCT airlineName FROM Flight")
	List<Flight> findByFlightNumberIsNull();

	@Query("select f from Flight f where (f.startDate between ?1 and ?2 ) and f.fromPlace = ?3 and f.toPlace=?4 and blockStatus=?5")
	List<Flight> findByFlightDetails(LocalDateTime startDate, LocalDateTime endDate, String fromPlace, String toPlace,int blckStatus, String tripType);

	List<Flight> findByAirlineNameAndFlightNumberIsNull(String airlineName);
	
//	@Query("SELECT e FROM Flight e WHERE e.airlineName IN (:airlineNames)")
//	List<Flight> findByAirlineNames(@Param("airlineNames")List<String> airlineNames);
}
