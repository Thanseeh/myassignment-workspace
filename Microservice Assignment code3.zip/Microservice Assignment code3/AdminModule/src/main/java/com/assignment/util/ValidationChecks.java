package com.assignment.util;

import com.assignment.entity.Flight;
import com.assignment.exceptions.NotFoundException;
import com.assignment.model.AirlineVo;
import com.assignment.model.FlightVo;

public class ValidationChecks {
	
	public static boolean airlineChecks(Flight flightVo) throws NotFoundException {
		if (flightVo == null)
			throw new NotFoundException("Flight cannot be null");
		if (flightVo.getAirlineName() == null)
			throw new NotFoundException("Airline name cannot be null");
		if (flightVo.getAirlineName().isEmpty())
			throw new NotFoundException("Airline name cannot be empty");
		return true;
	}
	
	public static boolean airlineChecks(AirlineVo flightVo) throws NotFoundException {
		if (flightVo == null)
			throw new NotFoundException("Flight cannot be null");
		if (flightVo.getAirlineName() == null)
			throw new NotFoundException("Airline name cannot be null");
		if (flightVo.getAirlineName().isEmpty())
			throw new NotFoundException("Airline name cannot be empty");
		return true;
	}
	
	public static boolean flightChecks(Flight flightVo) throws NotFoundException {
		if (flightVo == null)
			throw new NotFoundException("Flight cannot be null");
		if (flightVo.getAirlineName() == null)
			throw new NotFoundException("Airline name cannot be null");
		if (flightVo.getAirlineName().isEmpty())
			throw new NotFoundException("Airline name cannot be empty");
		if (flightVo.getFlightNumber() == null)
			throw new NotFoundException("Flight Number cannot be null");
		if (flightVo.getFlightNumber().isEmpty())
			throw new NotFoundException("Flight Number cannot be empty");
		if(flightVo.getFromPlace() == null)
			throw new NotFoundException("please specify FROM place");
		if(flightVo.getFromPlace().isEmpty())
			throw new NotFoundException("FROM place cannot be empty");
		if(flightVo.getToPlace() == null)
			throw new NotFoundException("please specify TO place");
		if(flightVo.getToPlace().isEmpty())
			throw new NotFoundException("TO place cannot be empty");
		if(flightVo.getStartDate()==null)
			throw new NotFoundException("Start date cannot be null");
		if(flightVo.getEndDate() == null)
			throw new NotFoundException("end date cannot be null");
		return true;
	}
	
	public static boolean flightChecks(FlightVo flightVo) throws NotFoundException {
		if (flightVo == null)
			throw new NotFoundException("Flight cannot be null");
		if (flightVo.getAirlineName() == null)
			throw new NotFoundException("Airline name cannot be null");
		if (flightVo.getAirlineName().isEmpty())
			throw new NotFoundException("Airline name cannot be empty");
		if (flightVo.getFlightNumber() == null)
			throw new NotFoundException("Flight Number cannot be null");
		if (flightVo.getFlightNumber().isEmpty())
			throw new NotFoundException("Flight Number cannot be empty");
		if(flightVo.getFromPlace() == null)
			throw new NotFoundException("please specify FROM place");
		if(flightVo.getFromPlace().isEmpty())
			throw new NotFoundException("FROM place cannot be empty");
		if(flightVo.getToPlace() == null)
			throw new NotFoundException("please specify TO place");
		if(flightVo.getToPlace().isEmpty())
			throw new NotFoundException("TO place cannot be empty");
		if(flightVo.getStartDate()==null)
			throw new NotFoundException("Start date cannot be null");
		if(flightVo.getEndDate() == null)
			throw new NotFoundException("end date cannot be null");
		return true;
	}

}
