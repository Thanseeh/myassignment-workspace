package com.assignment.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataAccessException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.assignment.entity.Flight;
import com.assignment.exceptions.NotFoundException;
import com.assignment.model.AirlineVo;
import com.assignment.model.FlightVo;
import com.assignment.repository.FlightRepository;
import com.assignment.util.ConversionVo;
import com.assignment.util.ValidationChecks;

@Service
public class FlightService {

	@Autowired
	FlightRepository flightRepository;

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	private static final String TOPIC = "kafka_topic";

	public List<Flight> findByAirlineNameAndFlightNumberIsNull(String airlineName) {
		return flightRepository.findByAirlineNameAndFlightNumberIsNull(airlineName);
	}

	@Cacheable(key = "#airlineId", value = "flight-store")
	public Flight findById(int id) {
		Optional<Flight> flight = flightRepository.findById(id);
		if (flight.isPresent()) {
			return flight.get();
		}
		return null;
	}

	@CacheEvict(key = "#airlineId", value = "flight-store")
	public void deleteById(int airlineId) {
		flightRepository.deleteById(airlineId);

	}

	@CachePut(key = "#airlineId", value = "flight-store")
	public boolean updateFlight(int airlineId, Flight flight) {
		try {
			flight.setAirlineId(airlineId);
			flightRepository.save(flight);
		} catch (DataAccessException e) {
			return false;
		}
		return true;
	}

//	public List<Flight> viewAllFlight(){
//		flightRepository.findByFl
//	}

	public Flight addFlightorAirline(Flight flight) {
		return flightRepository.save(flight);
	}

	public AirlineVo addAirline(AirlineVo airline) throws NotFoundException {
		if (ValidationChecks.airlineChecks(airline)) {
			List<Flight> gettingFlightsByAirline = findByAirlineNameAndFlightNumberIsNull(airline.getAirlineName());
			if (gettingFlightsByAirline.size() == 0) {
				Flight flight = new Flight();
				flight.setAirlineName(airline.getAirlineName());
				flight.setAirlineLogo(airline.getAirlineLogo());
				Flight afterSave = addFlightorAirline(flight);
				if (afterSave != null) {
					airline.setAirlineId(afterSave.getAirlineId());
					return airline;
				}
			}else {
				throw new NotFoundException("Airline already exist");
			}
		}
		throw new NotFoundException("Airline cannot be added ");
	}

	public AirlineVo blockAirline(AirlineVo airline) throws NotFoundException {
		if (ValidationChecks.airlineChecks(airline)) {
			System.out.println("checking whether the block status is 1 to send kafka message");
			if (airline.getBlockStatus() == 1) {
				System.out.println(
						"Sending Message via kafka{Message = Blocked AirlineName : " + airline.getAirlineName() + "}");
				kafkaTemplate.send(TOPIC, "Blocked AirlineName : " + airline.getAirlineName());
				System.out.println("Message sent");
			}
			List<Flight> gettingFlightsByAirline = flightRepository.findByAirlineName(airline.getAirlineName());
			for (Flight flight : gettingFlightsByAirline) {
				flight.setAirlineName(airline.getAirlineName());
				flight.setAirlineLogo(airline.getAirlineLogo());
				flight.setBlockStatus(airline.getBlockStatus());
				addFlightorAirline(flight);
			}
			if (gettingFlightsByAirline.size() > 0) {
				airline.setAirlineId(gettingFlightsByAirline.get(0).getAirlineId());
				return airline;
			}
		}
		throw new NotFoundException("Airline cannot be blocked");
	}

	public FlightVo addFlight(FlightVo flightVo) throws NotFoundException {
		if (ValidationChecks.flightChecks(flightVo)) {
			List<Flight> gettingFlightsByAirline = findByAirlineNameAndFlightNumberIsNull(flightVo.getAirlineName());
			if (gettingFlightsByAirline.size() > 0) {
				List<Flight> findByAirlineNameAndFlightNumber = flightRepository
						.findByAirlineNameAndFlightNumber(flightVo.getAirlineName(), flightVo.getFlightNumber());
				if (findByAirlineNameAndFlightNumber.size() > 0) {
					throw new NotFoundException("Duplicate Flight");
				} else {
					Flight flight = ConversionVo.convertFlightVoToFlight(flightVo);
					flight.setBlockStatus(gettingFlightsByAirline.get(0).getBlockStatus());
					Flight afterSave = addFlightorAirline(flight);
					if (afterSave != null) {
						flightVo.setFlightId(afterSave.getAirlineId());
						return flightVo;
					}
				}
			}
		}
		throw new NotFoundException("Flight cannot be saved");
	}

	public List<AirlineVo> findAllAirline() {
		List<Flight> airlines = flightRepository.findByFlightNumberIsNull();
		List<AirlineVo> airlineVos = new ArrayList<AirlineVo>();
		for (Flight flight : airlines) {
			airlineVos.add(new AirlineVo(flight.getAirlineId(), flight.getAirlineName(), flight.getAirlineLogo(),
					flight.getBlockStatus()));
		}
		return airlineVos;
	}

	public List<FlightVo> findByFlightDeatils(FlightVo bookFlight) {
		List<Flight> findByFlightDetails = flightRepository.findByFlightDetails(bookFlight.getStartDate(),
				bookFlight.getEndDate(), bookFlight.getFromPlace(), bookFlight.getToPlace(), 0, "round");
		List<FlightVo> flightVos = new ArrayList<>();
		for (Flight flight : findByFlightDetails) {
			FlightVo flightVo = ConversionVo.convertFlightToFlightVo(flight);
			flightVos.add(flightVo);
		}
		return flightVos;
	}

}
