package com.assignment.admin;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.assignment.entity.Flight;
import com.assignment.exceptions.NotFoundException;
import com.assignment.repository.FlightRepository;
import com.assignment.service.FlightService;

@SpringBootTest
class AdminModuleApplicationTests {
	
	@Autowired
	private FlightService service;
	
	@MockBean
	private FlightRepository repo;
	
	@Test
	void findWhtherAnAirlineExists() throws NotFoundException {
		
		String airlineName = "Indian Airlines";
		List<Flight> arrayList = new ArrayList<Flight>();
		Flight flight = new Flight();
		flight.setAirlineName(airlineName);
		arrayList.add(flight);
		Mockito.when(repo.findByAirlineName(airlineName)).thenReturn(arrayList);
		
		List<Flight> findWhetherAirlineExist = service.findByAirlineNameAndFlightNumberIsNull(airlineName);
		
		Assertions.assertNotNull(findWhetherAirlineExist);
	}
	
//	@Test
//	void findWhtherAnAirlineExists1() throws NotFoundException {
//		
//		String airlineName = "";
//		List<Flight> arrayList = new ArrayList<Flight>();
//		arrayList.add(new Flight());
//		Mockito.when(repo.findByAirlineName(airlineName)).thenReturn(arrayList);
//		
//		
//		Assertions.assertThrows(NotFoundException.class, () ->{
//			service.findByAirlineNameAndFlightNumberIsNull(airlineName);
//		});
//		
//	}
//	
//	@Test
//	void findWhtherAnAirlineExists2() throws NotFoundException {
//		
//		String airlineName = null;
//		List<Flight> arrayList = new ArrayList<Flight>();
//		arrayList.add(new Flight());
//		Mockito.when(repo.findByAirlineName(airlineName)).thenReturn(arrayList);
//		
//		
//		Assertions.assertThrows(Exception.class, () ->{
//			service.findByAirlineNameAndFlightNumberIsNull(airlineName);
//		});
//		
//	}

}
