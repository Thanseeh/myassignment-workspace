package com.assignment.discovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
