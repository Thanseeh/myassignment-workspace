package com.assignment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.assignment.entity.BookFlight;

public interface BookFlightRepository extends JpaRepository<BookFlight, Integer>{

	List<BookFlight> findByPnrNo(String pnrNo);

	List<BookFlight> findByEmailId(String emailId);

	List<BookFlight> findByFlightAirlineName(String airline);
}
