package com.assignment.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.assignment.entity.BookFlight;
import com.assignment.model.BookFlightVo;
import com.assignment.model.PassengerVo;
import com.assignment.repository.BookFlightRepository;
import com.assignment.util.DateConversion;
import com.assignment.util.FindPnr;

@Service
public class UserService {
	
	
	@Autowired
	BookFlightRepository bookFlightRepository;
	
	@Cacheable(key="#pnrNo",value="bookflight-store")
	public List<BookFlight> findByPnrNo(String pnrNo) {
		return bookFlightRepository.findByPnrNo(pnrNo);
		
	}

	public List<BookFlight> findByEmailId(String emailId) {
		return bookFlightRepository.findByEmailId(emailId);
		
	}

	public void addFlightBooking(BookFlightVo bookFlight) {
		List<PassengerVo> passengers = bookFlight.getPassengers();
		String generatedPnr = FindPnr.getPnrNo(6);
		for (PassengerVo passengerVo : passengers) {
			BookFlight bFlight = new BookFlight();
			bFlight.setUserName(bookFlight.getUserName());
			bFlight.setEmailId(bookFlight.getEmailId());
			bFlight.setFlightNo(bookFlight.getFlightNo());
			bFlight.setEmailId(bookFlight.getEmailId());
			bFlight.setBookFlightTime(bookFlight.getBookFlightTime());
			bFlight.setPnrNo(generatedPnr);
			bFlight.setBookMeal(bookFlight.getBookMeal());
			bFlight.setPassengerName(passengerVo.getPassengerName());
			bFlight.setPassengerGender(passengerVo.getPassengerGender());
			bFlight.setAge(passengerVo.getAge());
			bFlight.setBookStatus("booked");
			bookFlightRepository.save(bFlight);
		}
	}

	public void deleteFlightBooking(String pnrNo) {
		List<BookFlight> findByPnrNo = bookFlightRepository.findByPnrNo(pnrNo);
		for (BookFlight bookFlight : findByPnrNo) {
			long findDifferenceOfDate = DateConversion.findDifferenceOfDate(bookFlight.getBookFlightTime());
			if(findDifferenceOfDate >= 1) {
				bookFlight.setBookStatus("cancelled");
				bookFlightRepository.delete(bookFlight);
			}
		}
		
	}

//	public List<Flight> findByFlightDeatils(Flight bookFlight) {
//		return flightRepository.findByFlightDetails(bookFlight.getStartDate(),bookFlight.getEndDate(),bookFlight.getFromPlace(),
//				bookFlight.getToPlace(),0,"round");
//	}

	
	  
	
}
