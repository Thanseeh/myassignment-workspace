package com.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.exceptions.NotFoundException;
import com.assignment.model.FlightVo;
import com.assignment.service.FlightService;

@RestController
@RequestMapping("/api/v1.0/flight/user")
public class CommunicationController {


	@Autowired
	FlightService flightService;
	
	@PostMapping("/search")
	public List<FlightVo> findBy(@RequestBody FlightVo bookFlight) throws NotFoundException {
		return flightService.findByFlightDeatils(bookFlight);
	}
	
	
}
