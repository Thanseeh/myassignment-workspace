package com.assignment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.entity.Flight;
import com.assignment.exceptions.NotFoundException;
import com.assignment.model.AirlineVo;
import com.assignment.model.FlightVo;
import com.assignment.repository.FlightRepository;

@Service
public class FlightService {

	@Autowired
	FlightRepository flightRepository;

	public List<Flight> findWhetherAirlineExist(String airlineName) {
		return flightRepository.findByAirlineName(airlineName);
	}

	public Flight addFlightorAirline(Flight flight) {
		return flightRepository.save(flight);
	}

	public AirlineVo addAirline(AirlineVo airline) throws NotFoundException {
		List<Flight> gettingFlightsByAirline = findWhetherAirlineExist(airline.getAirlineName());
		if (gettingFlightsByAirline.size() == 0) {
			Flight flight = new Flight();
			flight.setAirlineName(airline.getAirlineName());
			flight.setAirlineLogo(airline.getAirlineLogo());
			Flight afterSave = addFlightorAirline(flight);
			if (afterSave != null) {
				airline.setAirlineId(afterSave.getAirlineId());
				return airline;
			}
		}
		throw new NotFoundException("Duplicate Airline");
	}

	public AirlineVo blockAirline(AirlineVo airline) throws NotFoundException {
		List<Flight> gettingFlightsByAirline = findWhetherAirlineExist(airline.getAirlineName());
		for (Flight flight : gettingFlightsByAirline) {
			flight.setAirlineName(airline.getAirlineName());
			flight.setAirlineLogo(airline.getAirlineLogo());
			flight.setBlockStatus(airline.getBlockStatus());
			addFlightorAirline(flight);
		}
		if (gettingFlightsByAirline.size() > 0) {
			return airline;
		}
		throw new NotFoundException("No Airline exist to block");
	}

	public FlightVo addFlight(FlightVo flightVo) throws NotFoundException {
		List<Flight> gettingFlightsByAirline = findWhetherAirlineExist(flightVo.getAirlineName());
		if (gettingFlightsByAirline.size() > 0) {
			List<Flight> findByAirlineNameAndFlightNumber = flightRepository
					.findByAirlineNameAndFlightNumber(flightVo.getAirlineName(), flightVo.getFlightNumber());
			if (findByAirlineNameAndFlightNumber.size() > 0) {
				throw new NotFoundException("Duplicate Flight");
			} else {
				Flight flight = new Flight();
				flight.setAirlineName(flightVo.getAirlineName());
				flight.setBusinessSeat(flightVo.getBusinessSeat());
				flight.setEndDate(flightVo.getEndDate());
				flight.setFlightNumber(flightVo.getFlightNumber());
				flight.setFromPlace(flightVo.getFromPlace());
				flight.setMeals(flightVo.getMeals());
				flight.setNonBusinessSeat(flightVo.getNonBusinessSeat());
				flight.setNoOfRows(flightVo.getNoOfRows());
				flight.setScheduleDays(flightVo.getScheduleDays());
				flight.setStartDate(flightVo.getStartDate());
				Flight afterSave = addFlightorAirline(flight);
				if (afterSave != null) {
					flightVo.setFlightId(afterSave.getAirlineId());
					return flightVo;
				}
			}
		}
		throw new NotFoundException("No Airline exist");
	}

	public List<AirlineVo> findAllAirline() {
		List<Flight> airlines = flightRepository.findByFlightNumberIsNull();
		List<AirlineVo> airlineVos = new ArrayList<AirlineVo>();
		for (Flight flight : airlines) {
			airlineVos.add(new AirlineVo(flight.getAirlineId(), flight.getAirlineName(), flight.getAirlineLogo(),
					flight.getBlockStatus()));
		}
		return airlineVos;
	}

	public List<FlightVo> findByFlightDeatils(FlightVo bookFlight) throws NotFoundException {
		List<Flight> findByFlightDetails = flightRepository.findByFlightDetails(bookFlight.getStartDate(),
				bookFlight.getEndDate(), bookFlight.getFromPlace(), bookFlight.getToPlace(), 0, "round");
		List<FlightVo> flightVos = new ArrayList<>();
		for (Flight flight : findByFlightDetails) {
			FlightVo flightVo = new FlightVo();
			flightVo.setAirlineName(flight.getAirlineName());
			flightVo.setBusinessSeat(flight.getBusinessSeat());
			flightVo.setEndDate(flight.getEndDate());
			flightVo.setFlightNumber(flight.getFlightNumber());
			flightVo.setFromPlace(flight.getFromPlace());
			flightVo.setMeals(flight.getMeals());
			flightVo.setNonBusinessSeat(flight.getNonBusinessSeat());
			flightVo.setNoOfRows(flight.getNoOfRows());
			flightVo.setScheduleDays(flight.getScheduleDays());
			flightVo.setStartDate(flight.getStartDate());
			flightVos.add(flightVo);
		}
//		if(flightVos.size() == 0)
//			throw new NotFoundException("No Flight Exist");
		return flightVos;
	}
}
