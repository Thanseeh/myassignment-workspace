package com.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.exceptions.NotFoundException;
import com.assignment.model.AirlineVo;
import com.assignment.model.FlightVo;
import com.assignment.service.FlightService;

@RestController
@RequestMapping("/api/v1.0/flight/admin")
public class AdminController {

	@Autowired
	FlightService flightService;
	
	
	
	/*
		http://localhost:8080/api/v1.0/flight/admin/airline
	*/
	@GetMapping("/airline")
	public List<AirlineVo> getAirline() {
		return flightService.findAllAirline();
	}
	
	/*
		http://localhost:8080/api/v1.0/flight/admin/airline/register
	*/
	@PostMapping("/airline/register")
	public AirlineVo addAirline(@RequestBody AirlineVo airline) throws NotFoundException {
		return flightService.addAirline(airline);
	}
	
	/*
	http://localhost:8080/api/v1.0/flight/admin/airline/block
	 */
	@PostMapping("/airline/block")
	public AirlineVo blockAirline(@RequestBody AirlineVo airline) throws NotFoundException {
		return flightService.blockAirline(airline);
	}
	
	/*
	http://localhost:8080/api/v1.0/flight/admin/airline/inventory/add
	 */
	@PostMapping("/airline/inventory/add")
	public FlightVo addFlight(@RequestBody FlightVo flight) throws NotFoundException {
		System.out.println(flight);
		return flightService.addFlight(flight);
	}
	
	
//	@Autowired
//	AdminService adminService;
	
//	@PostMapping("/login")
//	public boolean loginCheck(@RequestBody Admin admin) throws NotFoundException {
//		 return adminService.login(admin);
//	}
	
//	@PutMapping("/airline/inventory/update")
//	public void updateFlight(@RequestBody Flight airline) {
//		flightService.updateFlight();
//	}
	
//	@DeleteMapping("/deleteFlight")
//	public void deleteFlight() {
//		flightService.deleteFlight();
//	}
	
//	@PostMapping("")
//	public void addMeals() {
//		
//	}
//	
//	@PutMapping("")
//	public void updateMeals() {
//		
//	}
//	
//	@DeleteMapping("")
//	public void deleteMeals() {
//		
//	}
	
}
