package com.assignment.util;

import java.util.HashMap;
import java.util.Map;

public class Constants {

	@SuppressWarnings("serial")
	public final static Map<String, String> ADMIN_USERS = new HashMap<String, String>() {
		{
			put("admin", "$2a$10$UMWp0zv0MidT07kxU0VCkOl79AxWn4ldE/r5ZsYrOK82zc1ZrhSxS");
			put("thanseeh", "$2a$10$7ix2icF03R10mn9ILfmwpO2cmLP5aQjeZvybDGPf.4GzrLQa40/kS");
		}
	};

}
