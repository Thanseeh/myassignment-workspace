package com.assignment.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.NonNull;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "AIRLINE_FLIGHT")
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="AR_ID")
	private int airlineId;
	
	@Column(name="AR_NAME")
	@NonNull
	private String airlineName;
	
	@Column(name="AR_LOGO")
	private String airlineLogo;
	
	@Column(name="AR_BLOCK")
	private int blockStatus;
	
	@Column(name="FL_FROM")
	private String fromPlace;
	
	@Column(name="FL_TO")
	private String toPlace;
	
	@Column(name="FL_START")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",shape = JsonFormat.Shape.STRING, timezone = "GMT+8")
	private LocalDateTime startDate;
	
	@Column(name="FL_END")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", shape = JsonFormat.Shape.STRING, timezone = "GMT+8")
	private LocalDateTime endDate;
	
	@Column(name="FL_FLIGHTNO")
	private String flightNumber;
	
	@Column(name="FL_BS")
	private int businessSeat;
	
	@Column(name="FL_NOTBS")
	private int nonBusinessSeat;
	
	@Column(name="FL_ROWS")
	private int noOfRows;
	
	@Column(name="FL_COST")
	private int totalCost;
	
	@Column(name="FL_MEALS")
	private String meals;
	
	@Column(name="FL_SCHEDULE")
	private String scheduleDays;

	public int getAirlineId() {
		return airlineId;
	}

	public void setAirlineId(int airlineId) {
		this.airlineId = airlineId;
	}

	public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	public String getAirlineLogo() {
		return airlineLogo;
	}

	public void setAirlineLogo(String airlineLogo) {
		this.airlineLogo = airlineLogo;
	}

	public int getBlockStatus() {
		return blockStatus;
	}

	public void setBlockStatus(int blockStatus) {
		this.blockStatus = blockStatus;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public int getBusinessSeat() {
		return businessSeat;
	}

	public void setBusinessSeat(int businessSeat) {
		this.businessSeat = businessSeat;
	}

	public int getNonBusinessSeat() {
		return nonBusinessSeat;
	}

	public void setNonBusinessSeat(int nonBusinessSeat) {
		this.nonBusinessSeat = nonBusinessSeat;
	}

	public int getNoOfRows() {
		return noOfRows;
	}

	public void setNoOfRows(int noOfRows) {
		this.noOfRows = noOfRows;
	}

	public int getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}

	public String getMeals() {
		return meals;
	}

	public void setMeals(String meals) {
		this.meals = meals;
	}

	public String getScheduleDays() {
		return scheduleDays;
	}

	public void setScheduleDays(String scheduleDays) {
		this.scheduleDays = scheduleDays;
	}

	public String getFromPlace() {
		return fromPlace;
	}

	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}

	public String getToPlace() {
		return toPlace;
	}

	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}

	@Override
	public String toString() {
		return "Flight [airlineId=" + airlineId + ", airlineName=" + airlineName + ", airlineLogo=" + airlineLogo
				+ ", blockStatus=" + blockStatus + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", flightNumber=" + flightNumber + ", businessSeat=" + businessSeat + ", nonBusinessSeat="
				+ nonBusinessSeat + ", noOfRows=" + noOfRows + ", totalCost=" + totalCost + ", meals=" + meals
				+ ", scheduleDays=" + scheduleDays + "]";
	}
	
	
	
}
