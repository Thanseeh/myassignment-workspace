package com.assignment.advice;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.assignment.exceptions.NotFoundException;
import com.assignment.model.ErrorResponse;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<ErrorResponse> handle(NotFoundException e) {
		return new ResponseEntity<ErrorResponse>(
			new ErrorResponse(e.getMessage(), LocalDateTime.now()), 
			HttpStatus.OK
		);
	}
	
	@ExceptionHandler(ServletException.class)
	public ResponseEntity<ErrorResponse> handle(ServletException e) {
		return new ResponseEntity<ErrorResponse>(
			new ErrorResponse(e.getMessage(), LocalDateTime.now()), 
			HttpStatus.OK
		);
	}
	
	@ExceptionHandler(IOException.class)
	public ResponseEntity<ErrorResponse> handle(IOException e) {
		return new ResponseEntity<ErrorResponse>(
			new ErrorResponse(e.getMessage(), LocalDateTime.now()), 
			HttpStatus.OK
		);
	}
	
	@ExceptionHandler(UsernameNotFoundException.class)
	public ResponseEntity<ErrorResponse> handle(UsernameNotFoundException e) {
		return new ResponseEntity<ErrorResponse>(
			new ErrorResponse(e.getMessage(), LocalDateTime.now()), 
			HttpStatus.OK
		);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> handle(Exception e) {
		return new ResponseEntity<ErrorResponse>(
			new ErrorResponse(e.getMessage(), LocalDateTime.now()), 
			HttpStatus.OK
		);
	}
	
}
